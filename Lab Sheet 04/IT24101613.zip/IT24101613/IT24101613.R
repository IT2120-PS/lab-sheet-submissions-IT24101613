setwd("C:\\Users\\IT24101613\\Desktop\\IT24101613")
branch_data<-read.table("Exercise.txt",header=TRUE, sep=",")
attach(branch_data)

boxplot(Sales_X1, main="Boxplot for sales", outline=TRUE, outpch=8, horizontal=TRUE)

summary(Advertising_X2)
IQR(Advertising_X2)

get.outliers<-function(x) {
  q1<-quantile(x)[2]
  q3<-quantile(x)[4]
  iqr=q3-q1
  ub<-q3 + iqr*1.5
  lb<-q1 - iqr*1.5
  
  print(paste("Upper bound = ",ub))
  print(paste("Lower bound = ",lb))
  print(paste("Outliers: ", paste(sort(x[x<lb | x>ub]), collapse=",")))
}

get.outliers(Years_X3)
